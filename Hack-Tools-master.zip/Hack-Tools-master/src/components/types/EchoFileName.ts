type EchoFileName = {
	name: string;
	input: string;
};
